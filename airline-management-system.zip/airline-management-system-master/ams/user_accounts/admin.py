from django.contrib import admin
from .models import User, Passenger, Manager

admin.site.register(User)
admin.site.register(Passenger)
admin.site.register(Manager)

